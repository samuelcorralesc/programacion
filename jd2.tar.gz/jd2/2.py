a=int(input())
 
for i in range (0,a):
   if i%7!=0:
       print(i)
