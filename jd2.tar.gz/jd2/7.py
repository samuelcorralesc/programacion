while True:
   x, m = input().split()
   if(x == '0' and m == '0'):
       break
   print(int(x)*int(m))
