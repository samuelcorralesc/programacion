a=int(input())
b=int(input())
c=a-b
cont=1
while c!=0:
   c=c-b
   cont+=1
print('el cociente es',cont)
