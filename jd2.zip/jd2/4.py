cont=0
i=1
d=(5*12)+1
print(d)
while i <=12:
   m=(5*i)+1
   cont+=m
   i+=1
print(cont)
