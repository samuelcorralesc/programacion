a=0
while a!=2002:
   a=int(input())
   if a== 2002:
       print('Acesso Permitido')
   else:
       print('Senha Invalida')
