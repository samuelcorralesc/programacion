k=int(input())
n=int(input())
 
for i in range (n,k,-1):
   print(i)
