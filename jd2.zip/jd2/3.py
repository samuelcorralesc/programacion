cont=0
for i in range (97,1003):
   if i%2==0:
       m=i
       cont+=m
print(cont)
