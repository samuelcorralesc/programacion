k=1
suma=(k**2+1)/k
cont=0
while cont<1000:
   cont+=suma
   print(k)
   k+=1
   suma=(k**2+1)/k
